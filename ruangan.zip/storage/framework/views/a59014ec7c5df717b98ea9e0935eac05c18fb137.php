

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <h3>Ruang 
                    <button class="btn btn-primary float-right" data-toggle="modal" data-target="#modal-store" id="btn-add" data-backdrop="static" data-keyboard="false"><i class="far fa-paper-plane pr-2"></i> Tambah</button>
                <div class="table-responsive mt-5">
                </h3>
                    <table class="table" id="table" style="width:100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Kode</th>
                                <th>Posisi</th>
                                <th>Maksimal</th>
                                <th>Keterangan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('ruang.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    const Table = () => {
        let form = $('#form-store');
        let table = 'table';
        let url = '<?php echo e(route('ruang.index')); ?>';
        let column = [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
			{data: 'kode', name: 'kode'},
			{data: 'posisi', name: 'posisi'},
            {mData: 'maksimal',render :function(data,type,row){
                return data + ' orang';
            }
            },
            {data: 'keterangan', name: 'keterangan'},
            {mData: 'id',render :function(data,type,row){
                return `
	                      <a href="#" class="aksi edit" data-id="${data}"><i class="fas fa-edit ac"></i> </a>
	                      <a href="#" class="aksi delete" data-id="${data}"><i class="fas fa-times ac"></i> </a>`; 
            }
            },
        ]

        generateTable(table,url,column);
    }

    Table();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $('#btn-add').on('click', function () { 
        $('#id').val('');
        removeValidation();
    })
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $('#form-store').on('submit', function(e){
        e.preventDefault();
        removeAddValidation();
        let data = new FormData(this);
        let url = '<?php echo e(route('ruang.index')); ?>';
        storeData(data,url);
    });
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $('#table').on('click', '.edit', function(e) {
        e.preventDefault();
        removeValidation();
        $('#modal-title').text('Edit Ruang');
        let id = $(this).data('id');
        let url = '<?php echo e(route('ruang.index')); ?>'+'/'+id+'/edit';
        editData(url);
    })
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    $('#table').on('click', '.delete', function(e) {
        e.preventDefault();
        let id = $(this).data('id');
        let url = '<?php echo e(route('ruang.index')); ?>'+'/'+id;
        let konfirmasi = confirm('Apakah kamu yakin ingin mengahpus data Ini ?');
        if (konfirmasi == true) {
            deleteData(url);
        }
    })
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\ruangan\resources\views/ruang/index.blade.php ENDPATH**/ ?>