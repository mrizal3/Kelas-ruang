

<?php $__env->startSection('content'); ?>
<div class="row">
    <?php $__currentLoopData = $ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-12">
        <h2 class="section-title"><?php echo e($item->posisi); ?></h2>
        <div class="row">
            <?php $__currentLoopData = $item->ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="card card-info">
                    <div class="card-header">
                        <h4><?php echo e($value->kode); ?></h4><br>
                    </div>
                    <div class="card-body">
                        <p>Maksimal : <?php echo e($value->maksimal); ?> orang</p>
                        <p>Keterangan :</p>
                        <p><?php echo e($value->keterangan); ?></p>
                        <a href="<?php echo e(url('detail').'/'.$value->id); ?>" class="btn btn-info float-right">Detail</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web_application\Production\ruangan\resources\views/home/index.blade.php ENDPATH**/ ?>