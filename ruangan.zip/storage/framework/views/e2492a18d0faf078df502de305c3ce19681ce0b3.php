

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <h2 class="section-title">Ruang <?php echo e($ruang->kode); ?></h2>
        <div class="row">
            
            <div class="col-md-12">
                <h5>Jadwal Pelajaran</h5>
                <div class="table-responsive mt-4">
                    <table class="table table-bordered table-striped">
                        <tr>
                            <th>Hari</th>
                            <th>Jam</th>
                            <th>Kelas</th>
                            <th>Mata Kuliah</th>
                            <th>Semester</th>
                            <th>SKS</th>
                            <th>Dosen</th>
                            <th>Prodi</th>
                            <th>Keterangan</th>
                        </tr>
                        <?php $__currentLoopData = $hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $count = count($item->data);
                        ?>

                            <?php $__currentLoopData = $item->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if($key == 0): ?>
                                <td rowspan="<?php echo e($count); ?>"><?php echo e($item->hari); ?></td>
                                <?php endif; ?>
                                <td><?php echo e($data->jam_mulai.' - '.$data->jam_selesai); ?></td>
                                <td><?php echo e($data->kelas); ?></td>
                                <td><?php echo e($data->matkul); ?></td>
                                <td><?php echo e($data->semester); ?></td>
                                <td><?php echo e($data->sks); ?></td>
                                <td><?php echo e($data->dosen); ?></td>
                                <td><?php echo e($data->prodi); ?></td>
                                <td><?php echo e($data->keterangan); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web_application\Production\ruangan\resources\views/peminjam/ruang/index.blade.php ENDPATH**/ ?>