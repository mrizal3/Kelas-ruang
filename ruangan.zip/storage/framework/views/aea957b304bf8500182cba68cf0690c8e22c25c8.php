<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="layout-3">
    <div id="app">
        <div class="main-wrapper container">
            <div class="navbar-bg"></div>
            <?php echo $__env->make('layouts.partials._nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <nav class="navbar navbar-secondary navbar-expand-lg">

            </nav>

            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-body">
                        <div class="row">
                            <div class="col-md-12">
                                <h2 class="section-title">Gedung Belakang</h2>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="card card-info">
                                            <div class="card-header">
                                                <h4>Ruang R-213</h4>
                                            </div>
                                            <div class="card-body">
                                                <a href="" class="btn btn-info float-right">Selengkapnya</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="card card-info">
                                            <div class="card-header">
                                                <h4>Ruang R-213</h4>
                                            </div>
                                            <div class="card-body">
                                                <a href="" class="btn btn-info float-right">Selengkapnya</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="card card-info">
                                            <div class="card-header">
                                                <h4>Ruang R-213</h4>
                                            </div>
                                            <div class="card-body">
                                                <a href="" class="btn btn-info float-right">Selengkapnya</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="card card-info">
                                            <div class="card-header">
                                                <h4>Ruang R-213</h4>
                                            </div>
                                            <div class="card-body">
                                                <a href="" class="btn btn-info float-right">Selengkapnya</a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

        </div>
    </div>
    <?php echo $__env->make('layouts.partials._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\Users\Lenovo\Desktop\Kuliah\ruangan\resources\views/home/index.blade.php ENDPATH**/ ?>