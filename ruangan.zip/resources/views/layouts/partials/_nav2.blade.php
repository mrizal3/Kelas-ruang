<nav class="navbar navbar-expand-lg main-navbar">
    <a href="#up" class="navbar-brand sidebar-gone-hide"><i>Universitas Perjuangan</i></a>
    <a href="#" class="nav-link sidebar-gone-show" data-toggle="sidebar"><i class="fas fa-bars"></i></a>
    <form class="form-inline ml-auto">
    </form>
    <ul class="navbar-nav navbar-right">
        <a class="btn btn-lg btn-warning rounded-pill text-white" href="{{ url('/login') }}" style="border-radius: 50rem!important;">Login</a>
    </ul>
</nav>