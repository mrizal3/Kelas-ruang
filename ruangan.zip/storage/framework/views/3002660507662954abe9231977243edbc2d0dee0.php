<form id="form-store">
    <div class="modal fade" id="modal-store" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal-title">Tambah Barang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="id" name="id">
                <div class="form-group" id="nama_barang">
                    <label>Nama Barang</label>
                    <input type="text" autocomplete="off" class="form-control validation" name="nama_barang">
                </div>
                <div class="form-group" id="jumlah">
                    <label>Jumlah</label>
                    <input type="number" autocomplete="off" class="form-control validation" name="jumlah">
                </div>
                <div class="form-group" id="keterangan">
                    <label>Keterangan</label>
                    <textarea name="keterangan" class="form-control" cols="30" rows="10"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button class="btn btn-primary" type="submit">Simpan</button>
            </div>
        </div>
    </div>
</div>
</form><?php /**PATH C:\xampp1\htdocs\ruangan\resources\views/barang/modal.blade.php ENDPATH**/ ?>