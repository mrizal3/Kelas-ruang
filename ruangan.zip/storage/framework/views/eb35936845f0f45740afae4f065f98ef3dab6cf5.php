<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<style>
        @media (min-width: 1200px) {
        .container {
            max-width: 90% !important;
        }
    }
</style>

<body class="layout-3">
    <div id="app">
        <div class="main-wrapper container">
            <div class="navbar-bg"></div>
            <?php echo $__env->make('layouts.partials._nav2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <nav class="navbar navbar-secondary navbar-expand-lg">

            </nav>
            <?php echo $__env->make('layouts.partials._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Main Content -->
            <div class="main-content">
                <section class="section">
                    <div class="section-body">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </section>
                <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

        </div>
    </div>
    <?php echo $__env->make('layouts.partials._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp1\htdocs\ruangan\resources\views/layouts/master2.blade.php ENDPATH**/ ?>