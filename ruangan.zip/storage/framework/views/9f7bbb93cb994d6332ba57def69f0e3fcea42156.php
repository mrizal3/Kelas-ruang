<nav class="navbar navbar-expand-lg main-navbar">
    <a href="dashboard-general.html" class="navbar-brand sidebar-gone-hide">Stisla</a>
    <a href="#" class="nav-link sidebar-gone-show" data-toggle="sidebar"><i class="fas fa-bars"></i></a>
    <form class="form-inline ml-auto">
    </form>
    <ul class="navbar-nav navbar-right">
        <a class="btn btn-lg btn-warning rounded-pill text-white" href="<?php echo e(url('/login')); ?>" style="border-radius: 50rem!important;">Login</a>
    </ul>
</nav><?php /**PATH D:\web_application\Production\ruangan\resources\views/layouts/partials/_nav2.blade.php ENDPATH**/ ?>