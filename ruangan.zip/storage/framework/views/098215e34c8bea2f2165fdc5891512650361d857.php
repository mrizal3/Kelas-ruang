

<?php $__env->startSection('content'); ?>
<form method="GET">
    <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label>Prodi</label>
                <select name="prodi" class="form-control prodi">
                    <option value="">--- Prodi ---</option>
                    <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == request()->get('prodi') ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label>Kelas</label>
                <select name="kelas" class="form-control kelas"></select>
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group" id="angkatan">
                <label>Angkatan</label>
                <select name="angkatan" class="form-control validation angkatan">
                    <option value="">Angkatan</option>
                    <?php for($i = -5; $i < 5; $i++): ?> <option value="<?php echo e(date('Y')+$i); ?>"><?php echo e(date('Y')+$i); ?></option>
                        <?php endfor; ?>
                </select>
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label>Semester</label>
                <select name="semester" class="form-control semester">
                    <option value="">--- Semester ---</option>
                    <?php for($i = 1; $i < 13; $i++): ?> <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endfor; ?>
                </select>
            </div>
        </div>
        <div class="col-md-2">
            <div class="form-group" style="margin-top:1.9rem !important">
                <button class="btn btn-success"><i class="fas fa-search"></i> Filter</button>
                <button class="btn btn-info" onclick="printDiv('printableArea')"><i class="fas fa-print"></i> Print</button>
            </div>
        </div>
    </div>
</form>
<div class="row" id="printableArea">
    <table class="table table-bordered table-striped" >
        <tr>
            <th>Hari</th>
            <th>Jam</th>
            <th>Ruang</th>
            <th>Mata Kuliah</th>
            <th>SKS</th>
            <th>Dosen</th>
            <th>Prodi</th>
            <th>Keterangan</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $data_jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
        $count = count($item->data);
        ?>

            <?php $__empty_2 = true; $__currentLoopData = $item->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
            <tr>
                <?php if($key == 0): ?>
                <td rowspan="<?php echo e($count); ?>"><?php echo e($item->hari); ?></td>
                <?php endif; ?>
                <td width="15%"><?php echo e(date('H:i', strtotime($data->jam_mulai)).' - '.date('H:i', strtotime($data->jam_selesai))); ?></td>
                <td><?php echo e($data->ruang); ?></td>
                <td><?php echo e($data->matkul.'/'.$data->semester.$data->kelas); ?></td>
                <td><?php echo e($data->sks); ?></td>
                <td><?php echo e($data->dosen); ?></td>
                <td><?php echo e($data->prodi); ?></td>
                <td><?php echo e($data->keterangan); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
            
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <?php endif; ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    const getKelas = (id, kelas_id = null) => {
    let kelas = '<option value="">--- Kelas ---</option>';
    if (id !== '') {
        let url = '<?php echo e(url('ajax/search_kelas')); ?>'+'/'+id;
        $.ajax({
            async:true,
            type:'GET',
            cache: false,
            contentType: false,
            processData: false,
            async: true,
            url: url,
            beforeSend:function(request) {
                loading();
            },
            success: function(data){
                closeLoading();
                if (data != null) {
                    $.each(data, function(key,value) {
                        kelas += `<option value="${value.id}">${value.kode}</option>`;
                    })
                }
                $('.kelas').html(kelas)
                <?php if(request()->get('kelas') != null): ?>
                    $('.kelas').val(<?php echo e(request()->get('kelas')); ?>).attr('selected', true);
                <?php endif; ?>
                if (kelas_id != null) {
                    $('.kelas').val(kelas_id);
                }
            },
            error: function (error) {
            closeLoading();
            },
        })
    }
    else {
        $('.kelas').html(kelas)
    }
}

    $('.prodi').on('change', function() {
        let id = $(this).val();
        getKelas(id)
    })
    
    <?php if(request()->get('prodi') != null): ?>
        getKelas(<?php echo e(request()->get('prodi')); ?>)
    
    <?php endif; ?>

    <?php if(request()->get('semester') != null): ?>
        $('.semester').val(<?php echo e(request()->get('semester')); ?>);
    
    <?php endif; ?>

    <?php if(request()->get('angkatan') != null): ?>
        $('.angkatan').val(<?php echo e(request()->get('angkatan')); ?>);
    
    <?php endif; ?>

    function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
    
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\ruangan\resources\views/home/ruang.blade.php ENDPATH**/ ?>