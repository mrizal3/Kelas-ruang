<nav class="navbar navbar-secondary navbar-expand-lg">
    <div class="container">
        <ul class="navbar-nav">
            <?php if(auth()->user() != null): ?>
            <?php if(auth()->user()->level == 0): ?>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'dashboard')); ?>">
                <a href="<?php echo e(url('admin/dashboard')); ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <li class="nav-item dropdown <?php echo e(active_class(getUri(2), 'fakultas').active_class(getUri(2), 'ruang').active_class(getUri(2), 'matkul').active_class(getUri(2), 'kelas')); ?>">
                <a href="#" data-toggle="dropdown" class="nav-link has-dropdown"><i
                        class="fas fa-th-large"></i><span>Master Data</span></a>
                <ul class="dropdown-menu">
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'fakultas')); ?>"><a href="<?php echo e(route('fakultas.index')); ?>" class="nav-link">Fakultas</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'ruang')); ?>"><a href="<?php echo e(route('ruang.index')); ?>" class="nav-link">Ruang</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'matkul')); ?>"><a href="<?php echo e(route('matkul.index')); ?>" class="nav-link">Mata Kuliah</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'kelas')); ?>"><a href="<?php echo e(route('kelas.index')); ?>" class="nav-link">Kelas</a></li>
                </ul>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'barang')); ?>">
                <a href="<?php echo e(url('admin/barang')); ?>" class="nav-link"><i class="fas fa-shopping-bag"></i><span>Barang</span></a>
            </li>
            <li class="nav-item dropdown <?php echo e(active_class(getUri(2), 'user'). active_class(getUri(2), 'jabatan').active_class(getUri(2), 'dosen')); ?>">
                <a href="#" data-toggle="dropdown" class="nav-link has-dropdown"><i
                        class="fas fa-users"></i><span>Management User</span></a>
                <ul class="dropdown-menu">
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'jabatan')); ?>"><a href="<?php echo e(url('admin/jabatan')); ?>" class="nav-link">Jabatan</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'user')); ?>"><a href="<?php echo e(url('admin/user')); ?>" class="nav-link">User</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'dosen')); ?>"><a href="<?php echo e(url('admin/dosen')); ?>" class="nav-link">Dosen</a></li>
                </ul>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'jadwal')); ?>">
                <a href="<?php echo e(url('admin/jadwal')); ?>" class="nav-link"><i class="fas fa-book"></i><span>Jadwal Mata Kuliah</span></a>
            </li>
            
            <?php elseif(auth()->user()->level == 1): ?>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'dashboard')); ?>">
                <a href="<?php echo e(url('akademik/dashboard')); ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'pengajuan')); ?>">
                <a href="<?php echo e(url('akademik/pengajuan')); ?>" class="nav-link"><i class="fab fa-elementor"></i><span>Pengajuan</span></a>
            </li>
            <?php elseif(auth()->user()->level == 2): ?>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'dashboard')); ?>">
                <a href="<?php echo e(url('peminjam/dashboard')); ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'pengajuan')); ?>">
                <a href="<?php echo e(url('peminjam/pengajuan')); ?>" class="nav-link"><i class="fab fa-elementor"></i><span>Pengajuan</span></a>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'arsip-data')); ?>">
                <a href="<?php echo e(url('peminjam/arsip-data')); ?>" class="nav-link"><i class="fas fa-book"></i><span>Arsip Data</span></a>
            </li>
            <?php elseif(auth()->user() == null): ?>
            
            <?php endif; ?>
            <?php else: ?>
            <li class="nav-item <?php echo e(active_class(getUri(1), '')); ?>">
                <a href="<?php echo e(url('')); ?>" class="nav-link"><i class="fas fa-home"></i><span>Home</span></a>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(1), 'jadwal')); ?>">
                <a href="<?php echo e(url('jadwal')); ?>" class="nav-link"><i class="fas fa-th-large"></i><span>Jadwal Mata Kuliah</span></a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<nav class="navbar navbar-secondary navbar-expand-lg">
    <div class="container">
        <ul class="navbar-nav">
            <?php if(auth()->user() != null): ?>
            <?php if(auth()->user()->level == 0): ?>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'dashboard')); ?>">
                <a href="<?php echo e(url('admin/dashboard')); ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <li class="nav-item dropdown <?php echo e(active_class(getUri(2), 'fakultas').active_class(getUri(2), 'ruang').active_class(getUri(2), 'matkul').active_class(getUri(2), 'kelas')); ?>">
                <a href="#" data-toggle="dropdown" class="nav-link has-dropdown"><i
                        class="fas fa-th-large"></i><span>Master Data</span></a>
                <ul class="dropdown-menu">
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'fakultas')); ?>"><a href="<?php echo e(route('fakultas.index')); ?>" class="nav-link">Fakultas</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'ruang')); ?>"><a href="<?php echo e(route('ruang.index')); ?>" class="nav-link">Ruang</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'matkul')); ?>"><a href="<?php echo e(route('matkul.index')); ?>" class="nav-link">Mata Kuliah</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'kelas')); ?>"><a href="<?php echo e(route('kelas.index')); ?>" class="nav-link">Kelas</a></li>
                </ul>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'barang')); ?>">
                <a href="<?php echo e(url('admin/barang')); ?>" class="nav-link"><i class="fas fa-shopping-bag"></i><span>Barang</span></a>
            </li>
            <li class="nav-item dropdown <?php echo e(active_class(getUri(2), 'user'). active_class(getUri(2), 'jabatan').active_class(getUri(2), 'dosen')); ?>">
                <a href="#" data-toggle="dropdown" class="nav-link has-dropdown"><i
                        class="fas fa-users"></i><span>Management User</span></a>
                <ul class="dropdown-menu">
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'jabatan')); ?>"><a href="<?php echo e(url('admin/jabatan')); ?>" class="nav-link">Jabatan</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'user')); ?>"><a href="<?php echo e(url('admin/user')); ?>" class="nav-link">User</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'dosen')); ?>"><a href="<?php echo e(url('admin/dosen')); ?>" class="nav-link">Dosen</a></li>
                </ul>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'jadwal')); ?>">
                <a href="<?php echo e(url('admin/jadwal')); ?>" class="nav-link"><i class="fas fa-book"></i><span>Jadwal Mata Kuliah</span></a>
            </li>
            
            <?php elseif(auth()->user()->level == 1): ?>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'dashboard')); ?>">
                <a href="<?php echo e(url('akademik/dashboard')); ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'pengajuan')); ?>">
                <a href="<?php echo e(url('akademik/pengajuan')); ?>" class="nav-link"><i class="fab fa-elementor"></i><span>Pengajuan</span></a>
            </li>
            <?php elseif(auth()->user()->level == 2): ?>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'dashboard')); ?>">
                <a href="<?php echo e(url('peminjam/dashboard')); ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'pengajuan')); ?>">
                <a href="<?php echo e(url('peminjam/pengajuan')); ?>" class="nav-link"><i class="fab fa-elementor"></i><span>Pengajuan</span></a>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'arsip-data')); ?>">
                <a href="<?php echo e(url('peminjam/arsip-data')); ?>" class="nav-link"><i class="fas fa-book"></i><span>Arsip Data</span></a>
            </li>
            <?php elseif(auth()->user() == null): ?>
            
            <?php endif; ?>
            <?php else: ?>
            <li class="nav-item <?php echo e(active_class(getUri(1), '')); ?>">
                <a href="<?php echo e(url('')); ?>" class="nav-link"><i class="fas fa-home"></i><span>Home</span></a>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(1), 'jadwal')); ?>">
                <a href="<?php echo e(url('jadwal')); ?>" class="nav-link"><i class="fas fa-th-large"></i><span>Jadwal Mata Kuliah</span></a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<?php /**PATH C:\xampp1\htdocs\ruangan\resources\views/layouts/partials/_menu.blade.php ENDPATH**/ ?>