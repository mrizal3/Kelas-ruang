<footer class="main-footer">
    <div class="footer-left">
        &copy; 2020/2021 <div class="bullet text-"><i>Universitas Perjuangan</i>
    </div>
    <div class="footer-right">

    </div>
</footer>	