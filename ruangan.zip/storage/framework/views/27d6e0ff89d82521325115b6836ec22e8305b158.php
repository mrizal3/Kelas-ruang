

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="invoice">
            <div class="invoice-print">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="invoice-title">
                            <h2>Pengajuan</h2>
                            <div class="invoice-number">Nomor : <input type="text" class="form-control nomor" name="nomor" value="<?php echo e($peminjaman->nomor); ?>" autocomplete="off"></div>
                        </div>
                        <hr>
                    </div>
                    <div class="col-lg-6">
                        <table class="table table-striped">
                            <tr>
                                <td>Perihal : <?php echo e($peminjaman->perihal); ?></td>
                            </tr>
                            <tr>
                                <td>Agenda : <?php echo e($peminjaman->agenda); ?></td>
                            </tr>
                            <tr>
                                <td>Ruang : <?php echo e($peminjaman->ruang->kode); ?></td>
                            </tr>
                            <tr>
                                <td>Jumlah Orang : <?php echo e($peminjaman->jumlah_orang); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-lg-6">
                        <table class="table table-striped">
                            <tr>
                                <td>Peminjam : <?php echo e($peminjaman->user->nama); ?></td>
                            </tr>
                            <tr>
                                <td>Tanggal Dibuat : <?php echo e(formatDate2($peminjaman->tanggal_dibuat)); ?></td>
                            </tr>
                            <tr>
                                <td>Tanggal Pelaksaan : <?php echo e(formatDate2($peminjaman->tanggal_mulai)); ?> - <?php echo e(formatDate2($peminjaman->tanggal_selesai)); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
        
                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="section-title">Detail Pengajuan</div>
                        
                        <div class="table-responsive">
                            <table class="table table-striped table-hover table-md">
                                <tr>
                                    <th data-width="40">#</th>
                                    <th>Nama Barang</th>
                                    <th class="text-center">Jumlah</th>
                                </tr>
                                <tr>
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $peminjaman->detail_peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e($item->barang->nama_barang); ?></td>
                                        <td class="text-center"><?php echo e($item->jumlah); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">Tidak Ada Data</td>
                                    </tr>
                                    <?php endif; ?>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="text-md-right">
                <div class="float-lg-left mb-lg-0 mb-3">
                    <?php if($peminjaman->status == 0): ?>
                    <button class="btn btn-success btn-icon icon-left setuju"><i class="fas fa-check"></i> Setujui</button>
                    <button class="btn btn-danger btn-icon icon-left btn-tolak"><i class="fas fa-times"></i> Tolak</button>
                    <?php elseif($peminjaman->status == 1): ?>
                    <button class="btn btn-danger btn-icon icon-left btn-tolak"><i class="fas fa-times"></i> Tolak</button>
                    <?php else: ?>
                    <button class="btn btn-success btn-icon icon-left setuju"><i class="fas fa-check"></i> Setujui</button>
                    <?php endif; ?>
                    
                </div>
                <a href="<?php echo e(url('akademik/pengajuan').'/'.getUri(3)); ?>/surat" class="btn btn-info btn-icon icon-left"><i class="fas fa-print"></i> Print Surat</a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('akademik.pengajuan.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    let url = '<?php echo e(url('akademik/pengajuan/ubah_status')); ?>';
    let id = '<?php echo e(getUri(3)); ?>';
    $('.nomor').on('change', function() {
        let nomor = $(this).val();
        let status = 'nomor';

        $.post(url, {nomor:nomor, status:status, id:id}, function(result) {
            if (result.status == true) {
                successMessage('Berhasil Isi Nomor');
            }
            else {
                errorMessage('Gagal Mengisi Nomor !');
            }
        })
    })

    $('.setuju').on('click', function() {
        let status = 'setuju';
        let konfir = confirm('Apakah Yakin Menyetujui Pengajuan ini ?');
        if (konfir == true) {
            $.post(url, {status:status, id:id}, function(result) {
                if (result.status == true) {
                    successMessage('Pengajuan Disetujui');
                    setTimeout(function() {
                        window.location = '<?php echo e(url('akademik/pengajuan')); ?>';
                    },2000)
                }
                else {
                    errorMessage('Pengajuan Gagal Disetujui');
                }
            })
        }

    });

    $('.btn-tolak').on('click', function() {
        $('.keterangan').val('');
        $('.modal-tolak').modal('show');
    });

    $('.tolak').on('click', function() {
        let keterangan = $('.keterangan').val();
        let status = 'tolak';
        $.post(url, {status:status, id:id, keterangan:keterangan}, function(result) {
            if (result.status == true) {
                successMessage('Pengajuan Ditolak');
                setTimeout(function() {
                    window.location = '<?php echo e(url('akademik/pengajuan')); ?>';
                },2000)
            }
            else {
                errorMessage('Pengajuan Gagal Ditolak');
            }
            $('.modal-tolak').modal('hide');
        })
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web_application\Production\ruangan\resources\views/akademik/pengajuan/detail.blade.php ENDPATH**/ ?>