<nav class="navbar navbar-secondary navbar-expand-lg">
    <div class="container">
        <ul class="navbar-nav">
            <li class="nav-item <?php echo e(active_class(getUri(2), 'dashboard')); ?>">
                <a href="<?php echo e(url('admin/dashboard')); ?>" class="nav-link"><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <li class="nav-item dropdown <?php echo e(active_class(getUri(2), 'fakultas').active_class(getUri(2), 'ruang')); ?>">
                <a href="#" data-toggle="dropdown" class="nav-link has-dropdown"><i
                        class="fas fa-th-large"></i><span>Master Data</span></a>
                <ul class="dropdown-menu">
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'fakultas')); ?>"><a href="<?php echo e(route('fakultas.index')); ?>" class="nav-link">Fakultas</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'ruang')); ?>"><a href="<?php echo e(route('ruang.index')); ?>" class="nav-link">Ruang</a></li>
                </ul>
            </li>
            <li class="nav-item dropdown <?php echo e(active_class(getUri(2), 'user'). active_class(getUri(2), 'jabatan')); ?>">
                <a href="#" data-toggle="dropdown" class="nav-link has-dropdown"><i
                        class="fas fa-users"></i><span>Management User</span></a>
                <ul class="dropdown-menu">
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'jabatan')); ?>"><a href="<?php echo e(url('admin/jabatan')); ?>" class="nav-link">Jabatan</a></li>
                    <li class="nav-item <?php echo e(active_class(getUri(2), 'user')); ?>"><a href="<?php echo e(url('admin/user')); ?>" class="nav-link">User</a></li>
                </ul>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'jadwal')); ?>">
                <a href="<?php echo e(url('admin/jadwal')); ?>" class="nav-link"><i class="fas fa-book"></i><span>Jadwal Pelajaran</span></a>
            </li>
            <li class="nav-item <?php echo e(active_class(getUri(2), 'peminjaman-ruang')); ?>">
                <a href="<?php echo e(url('admin/peminjaman-ruang')); ?>" class="nav-link"><i class="fas fa-school"></i><span>Peminjaman Ruang</span></a>
            </li>
        </ul>
    </div>
</nav><?php /**PATH C:\Users\Lenovo\Desktop\Kuliah\ruangan\resources\views/layouts/partials/_menu.blade.php ENDPATH**/ ?>