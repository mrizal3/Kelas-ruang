<nav class="navbar navbar-expand-lg main-navbar">
    <a href="dashboard-general.html" class="navbar-brand sidebar-gone-hide">Stisla</a>
    <a href="#" class="nav-link sidebar-gone-show" data-toggle="sidebar"><i class="fas fa-bars"></i></a>
    <form class="form-inline ml-auto">
    </form>
    <ul class="navbar-nav navbar-right">
        <li class="dropdown"><a href="#" data-toggle="dropdown"
                class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                <div class="d-sm-none d-lg-inline-block"><?php echo e(auth()->user()->nama); ?></div>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <a href="<?php echo e(url('profile/ganti-password')); ?>" class="dropdown-item has-icon">
                    <i class="fas fa-lock"></i> Ganti Password
                </a>
                <div class="dropdown-divider"></div>
                <a  href="<?php echo e(url('logout')); ?>"
                onclick="event.preventDefault();
                              document.getElementById('logout-form').submit();" class="dropdown-item has-icon text-danger">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
                <form id="logout-form" action="<?php echo e(url('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </li>
    </ul>
</nav><?php /**PATH D:\web_application\Production\ruangan\resources\views/layouts/partials/_nav.blade.php ENDPATH**/ ?>